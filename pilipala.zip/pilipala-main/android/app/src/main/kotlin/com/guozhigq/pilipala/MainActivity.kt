package com.guozhigq.pilipala

// import io.flutter.embedding.android.FlutterActivity
import com.ryanheise.audioservice.AudioServiceActivity;

class MainActivity: AudioServiceActivity() {
    
}
