enum VideoEpidoesType {
  videoEpisode,
  videoPart,
  bangumiEpisode,
}
