library searchresult;

export './controller.dart';
export './view.dart';
