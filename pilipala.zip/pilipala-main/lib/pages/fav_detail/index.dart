library favdetail;

export './controller.dart';
export './view.dart';
