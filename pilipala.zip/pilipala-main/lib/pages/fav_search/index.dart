library fav_search;

export './controller.dart';
export './view.dart';
