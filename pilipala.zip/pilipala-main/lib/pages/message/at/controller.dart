import 'package:get/get.dart';

class MessageAtController extends GetxController {}
