library video_detail;

export './controller.dart';
export './view.dart';
