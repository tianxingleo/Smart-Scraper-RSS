library releated_video_panel;

export './controller.dart';
export './view.dart';
