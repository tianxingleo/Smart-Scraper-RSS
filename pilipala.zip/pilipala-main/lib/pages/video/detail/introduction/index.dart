library video_intro_panel;

export './controller.dart';
export './view.dart';
