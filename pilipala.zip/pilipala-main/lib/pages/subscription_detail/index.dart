library sub_detail;

export './controller.dart';
export './view.dart';
