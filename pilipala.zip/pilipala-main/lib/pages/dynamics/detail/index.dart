library dynamic_detail;

export './controller.dart';
export './view.dart';
