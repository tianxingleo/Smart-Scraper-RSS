import 'package:get/get.dart';

class MemberCoinController extends GetxController {}
