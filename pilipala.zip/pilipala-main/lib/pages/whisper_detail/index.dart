library whisper_detail;

export './controller.dart';
export './view.dart';
