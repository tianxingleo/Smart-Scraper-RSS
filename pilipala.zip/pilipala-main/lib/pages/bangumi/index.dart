library bangumi_panel;

export './controller.dart';
export './view.dart';
