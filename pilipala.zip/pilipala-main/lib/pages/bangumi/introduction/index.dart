library bangumi_intro;

export './controller.dart';
export './view.dart';
