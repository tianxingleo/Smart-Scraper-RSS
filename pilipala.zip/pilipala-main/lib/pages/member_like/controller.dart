import 'package:get/get.dart';

class MemberLikeController extends GetxController {}
