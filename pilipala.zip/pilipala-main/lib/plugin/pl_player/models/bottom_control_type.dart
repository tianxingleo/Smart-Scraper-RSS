enum BottomControlType {
  pre,
  playOrPause,
  next,
  time,
  space,
  episode,
  fit,
  speed,
  fullscreen,
  custom,
}
